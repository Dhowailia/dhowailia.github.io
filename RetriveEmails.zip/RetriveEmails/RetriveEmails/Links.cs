﻿namespace RetriveEmails
{
    public class Links
    {
    }
}
