﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace RetriveEmails
{
    public class DatabaseReader
    {
        private string _connectionString;

        string INDIADB = ConfigurationManager.ConnectionStrings["DENR"].ConnectionString;

        public DatabaseReader(string connectionString)
        {
            _connectionString = connectionString;
        }

        
    }
}